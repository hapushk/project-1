<?php

$apiKey = 'XvTDZO5wt4yQycBzzKCIGKIVrbuSh1zaEkoL66cMS1COLnCShnItdOj';          // Ключ доступа к API
$offer_id = 958;         // для каждого оффера свой айди, надо уточнять его в админке или у суппортов
$stream_hid = 'nGNF4zQR';     // id потока

$default_main_site = 'http://api.cpa.tl';
$apiSendLeadUrl = 'http://api.cpa.tl/api/lead/send_archive';
$apiGetLeadUrl = 'http://api.cpa.tl/api/lead/feed';

$dataOffers = '{"6376":{"currency":{"code":"RUB","name":"\u0440\u0443\u0431"},"name":"Renumax - \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043e \u0434\u043b\u044f \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u044f \u0446\u0430\u0440\u0430\u043f\u0438\u043d","id":6376,"price2":"1980","country":{"code":"RU","name":"\u0420\u043e\u0441\u0441\u0438\u044f"},"price":"990"},"13917":{"currency":{"code":"UAH","name":"\u0433\u0440\u043d"},"name":"Renumax - \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043e \u0434\u043b\u044f \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u044f \u0446\u0430\u0440\u0430\u043f\u0438\u043d","id":13917,"price2":"398","country":{"code":"UA","name":"\u0423\u043a\u0440\u0430\u0438\u043d\u0430"},"price":"199"},"14690":{"currency":{"code":"BYR","name":"Br"},"name":"Renumax - \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043e \u0434\u043b\u044f \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u044f \u0446\u0430\u0440\u0430\u043f\u0438\u043d","id":14690,"price2":"88","country":{"code":"BY","name":"\u0411\u0435\u043b\u0430\u0440\u0443\u0441\u044c"},"price":"44"}}';
$dataOffer = '{"currency":{"code":"RUB","name":"\u0440\u0443\u0431"},"name":"Renumax - \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043e \u0434\u043b\u044f \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u044f \u0446\u0430\u0440\u0430\u043f\u0438\u043d","id":6376,"price2":"1980","country":{"code":"RU","name":"\u0420\u043e\u0441\u0441\u0438\u044f"},"price":"990"}';
$productName = 'Renumax - средство для удаления царапин';
$invoice = 'index.php';
$push_link = '';
$language = 'ru';
$companyInfo = array('address' => '692913, КРАЙ ПРИМОРСКИЙ, ГОРОД НАХОДКА, УЛИЦА НАХИМОВСКАЯ, ДОМ 1, ОФИС 25', 'detail' => 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "ВОСТОК-ТОРГ" ОГРН: 1182536003737 ИНН: 2508132579 КПП: 250801001');

if(!$apiKey){
    echo 'Ключ доступа к API не определен. Получите в личном кабинете или обратитесь в службу поддержки';
    die;
}

if(!$offer_id){
    echo 'ID оффера не определен';
    die;
}
