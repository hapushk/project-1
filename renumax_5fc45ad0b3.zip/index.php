<?php require('onepage.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Renumax - средство для удаления царапин на машине</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=480">
    <meta name="description" content="RENUMAX - новое универсальное средство для удаления царапин и мелких повреждений автомобиля любой окраски.">
    <meta name="keywords" content="RENUMAX, удаление царапин на авто, удалление сколов на авто, приспособление для полировки авто, автомобильные акссесуары, новинка для авто, купить со скидкой, средство от царапин ЛКП авто">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <meta property="og:title" content="RENUMAX - новое универсальное средство для удаления царапин и мелких повреждений автомобиля любой окраски."/>
    <meta property="og:description" content="Активная формула RENUMAX, которая содержит миллионы полирующих микрочастиц, равномерно заполняет повреждённый участок Вашего автомобиля и восстанавливает первоначальный вид верхнего покрытия Вашей машины. Действие RENUMAX приятно удивит Вас своей простотой и эффективностью."/>
    <meta property="og:image" content="img/rew-1.jpg"/>
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700&subset=cyrillic" rel="stylesheet">
    <link media="all" href="css/fonts.css" rel="stylesheet" type="text/css" />
    <link media="all" href="css/main.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="js/count.js"></script>
    <script type="text/javascript" src="js/init.js"></script>
  </head>
  <body>
    <div class="main-wrap">
      <div class="section block-1">
        <div class="container">
          <div class="sale">Скидка<br/><b>50%</b></div>
          <div class="cost">
            <span class="old-cost"><s><?= $oldPriceHtml ?><?= $currencyDisplayHtml ?></s></span><br/>
            <span class="new-cost"><?= $newPriceHtml ?><?= $currencyDisplayHtml ?></span>
          </div>
        </div>
        <div class="timer clearfix">
          <p>ДО КОНЦА АКЦИИ ОСТАЛОСЬ:</p>
          <div class="countbox clearfix"></div>
          <a class="button-m" href="#order"></a>
        </div>
      </div>
      <div class="section block-2">
        <h1 class="zag"><span>Что такое</span> Renumax</h1>
        <div class="container">
          <div class="text">
            <p>RENUMAX - новое универсальное средство для удаления царапин и мелких повреждений автомобиля любой окраски. Активная формула RENUMAX, которая содержит миллионы полирующих микрочастиц, равномерно заполняет повреждённый участок Вашего автомобиля и восстанавливает первоначальный вид верхнего покрытия Вашей машины. Действие RENUMAX приятно удивит Вас своей простотой и эффективностью.</p>
            <ul class="clearfix">
              <li>Нетоксичен </li>
              <li>Долговечен</li>
              <li>Водостойкий</li>
              <li>Для всех цветов</li>
              <li>Без запаха</li>
            </ul>
          </div>
          <div class="video">
            <iframe width="100%" height="240" src="https://www.youtube.com/embed/rK4I2-b_miU" frameborder="0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
      <div class="section block-3" >
        <h2 class="zag"><span>Преимущества</span> Renumax</h2>
        <div class="container">
          <ul>
            <li>Избавит вас от дорогостоящих процедур!</li>
            <li>Удобный ремонт в любом месте.</li>
            <li>Заметный результат через 10 минут после применения! </li>
            <li>Простота использования и высокое качество.</li>
          </ul>
        </div>
      </div>
      <div class="section block-4">
        <h2 class="zag"><span>Отзывы о</span> Renumax</h2>
        <div class="rew-cont">
          <div class="rew-item">
            <img src="img/rew-1.jpg" >
            <div>
              <p>Михаил Липкович, г. Минск</p>
              «Посоветовал RENUMAX мне сотрудник по работе. Заезжая в гараж, поцарапал задний бампер и никак не мог решить каким образом скрыть царапину. Результат после применения средства мне очень понравился, это просто незаменимая вещь для автовладельцев.»
            </div>
          </div>
          <div class="rew-item">
            <img src="img/rew-2.jpg" >
            <div>
              <p>Виктор Митрохин, г. Москва</p>
              «Езжу я в принципе очень аккуратно, но в большом городе всякое случается, в общем, неприятно видеть свою красавицу в таком виде. Сосед посоветовал комплект для устранения царапин RENUMAX. Быстро, просто, эффективно привел кузов в порядок.»
            </div>
          </div>
          <div class="rew-item">
            <img src="img/rew-3.jpg" >
            <div>
              <p>Алена Смирнова, Омск</p>
              «Очень прост в использовании. Увидела в действии RENUMAX у коллеги по работе. Когда на моих глазах исчезла довольно большая царапина, тут же решила, что мне он очень нужен. Езжу я на родительской машине и RENUMAX всегда вожу с собой.»
            </div>
          </div>
          <div class="rew-item">
            <img src="img/rew-4.jpg" >
            <div>
              <p>Сергей Лебедев, Тверь</p>
              «В бурном потоке машин никто не застрахован от мелких повреждений корпуса. Друзья посоветовали RENUMAX, подумал, решил «чёрт с ним, попробую!». Ну и попробовал. Теперь ни за что не откажусь от этого чудесного продукта. Всем советую.»
            </div>
          </div>
        </div>
        <div class="center">
          <p><span>ПОПРОБУЙТЕ RENUMAX И ВЫ!</span><br/>Перестаньте тратить сумасшедшие деньги на устранение мелких повреждений корпуса Вашего автомобиля.</p>
          <a class="button-m" href="#order"></a>
        </div>
      </div>
      <div class="section block-5">
        <ul class="clearfix">
          <li>
            <p><span>Доставка почтой</span>, в течение от 1 до 10 рабочих дней.
             
            </p>
          </li>
          <li>
            <p><span>Никаких предоплат!</span> Оплата заказов осуществляется непосредственно по факту получения товара.</p>
          </li>
          <li>
            <p>Вы вправе отказаться от покупки <span>в течение 14 дней</span> с момента получения заказа, независимо от причины возврата.</p>
          </li>
        </ul>
      </div>
      <div class="section block-1 end" id="order">
        <div class="container">
          <div class="sale">Скидка<br/><b>50%</b></div>
          <div class="cost">
            <span class="old-cost"><s><?= $oldPriceHtml ?><?= $currencyDisplayHtml ?></s></span><br/>
            <span class="new-cost"><?= $newPriceHtml ?><?= $currencyDisplayHtml ?></span>
          </div>
        </div>
        <div class="right-cont">
          <p>До конца акции</p>
          <div class="countbox clearfix"></div>
          <form action="" method="post">
            <div><?= countrySelect() ?></div>
            <div><input type="text" name="name" placeholder="Введите Ф.И.О"></div>
            <div><input type="text" name="phone" placeholder="Введите телефон"></div>
            <div>
              <button class="button-m"></button>
              <p class="imgAlert">*внешний вид товара может отличаться от представленного на изображении</p>
            </div>
          </form>
        </div>
      </div>
      <div class="section footer">
        <div class="center" style="text-align: center; font-size: 14px;">
          <?= footer() ?>
          <style>
            .footer p {
            margin: 0;
            padding: 0;
            }
          </style>
        </div>
      </div>
    </div>
  </body>
</html>